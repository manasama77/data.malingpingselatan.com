<?php

namespace Mpdf\Tag;

class PageBreak extends FormFeed
{

}
